import java.util.Scanner;
public class T {
    // Para compilar javac T.java
    // Para executar java T < entrada
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int vagoes = 0;
        int vagao = 0;
        do{
            vagoes = sc.nextInt();
            if (vagoes == 0)
                break;
            while (true){
                for (int i=0; i<vagoes;++i){
                    vagao = sc.nextInt();
                    if (vagao==0)
                        break;
                    System.out.print(vagao + " ");
                }
                if (vagao==0)
                    break;
                System.out.println();
            }
            //System.out.println();
        } while(true);
    }
}